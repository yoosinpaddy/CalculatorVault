package com.kit.tools.box.disk.news.shopping.common;

/**
 * Created by ABC on 9/21/2017.
 */

public class BMIShareData {

    public static String weightdata;
    public static String height;
    public static float bmidata;
    public static String age;
    public static String date;
    public static String time;
    public static String model = "model";
    public static int mf;
    public static int wei;
    public static int hei;
    public static int we;
    public static int he;
    public static String key_ml = "key_ml";
    public static String key_we = "key_we";
    public static String key_he = "key_he";

}
