package com.kit.tools.box.disk.news.shopping.modle;


import java.util.ArrayList;

/**
 * Created by Vasundhara on 2/24/2018.
 */

public class NotiModel {

    private ArrayList<AdModel> list = new ArrayList<>();

    public ArrayList<AdModel> getList() {
        return list;
    }

    public void setList(ArrayList<AdModel> list) {
        this.list = list;
    }
}
